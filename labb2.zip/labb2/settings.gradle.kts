rootProject.name = "labb2"

