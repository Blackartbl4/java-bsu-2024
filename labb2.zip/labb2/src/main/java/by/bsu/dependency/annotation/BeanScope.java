package by.bsu.dependency.annotation;

public enum BeanScope {
    SINGLETON,
    PROTOTYPE
}
