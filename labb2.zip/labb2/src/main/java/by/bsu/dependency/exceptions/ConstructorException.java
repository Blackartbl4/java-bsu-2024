package by.bsu.dependency.exceptions;

public class ConstructorException extends RuntimeException {
    public ConstructorException(String str) {
        super(str);
    }
}
